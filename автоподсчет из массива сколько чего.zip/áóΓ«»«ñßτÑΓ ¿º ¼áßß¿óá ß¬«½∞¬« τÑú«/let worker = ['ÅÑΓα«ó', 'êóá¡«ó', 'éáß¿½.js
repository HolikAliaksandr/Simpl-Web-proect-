let worker = ['Петров', 'Иванов', 'Васильев', 'Яковлева', 'Степанова'];
let out_arr
let str = ' ';
for (let i = 0; i< worker.length; i++ ) {
if (worker[i]!==undefined) str += i+1 +' - ' + worker[i]+'  ';
}
console.log(str)


var arr = [
    [1, 2],
    [4, 5],
    [7, 8]
];
var result = [].concat(arr[0],arr[1],arr[2] );
console.log(result);