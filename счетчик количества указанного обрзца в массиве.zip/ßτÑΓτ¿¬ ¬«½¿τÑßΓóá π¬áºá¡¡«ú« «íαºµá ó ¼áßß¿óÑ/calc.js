const input1 = document.querySelector("#input1")
const input2 = document.querySelector("#input2")
const output = document.querySelector("#out")

const but = document.querySelector("#button")



but.addEventListener('click', function() {
    let y = 0

    mas = input1.value
    const search  = Array.from(mas)

    mass = input2.value
    const massiv = Array.from(mass)
    
    if(search.length>>1){
        alert("Вы ввели больше одного искомого символа")
    }

    for(const xKey of massiv){
        if(xKey==search[0]){
            y++
        }  
    }  
    output.innerText = y
})