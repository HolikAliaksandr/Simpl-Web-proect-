const input1 = document.querySelector("#input1")
const input2 = document.querySelector("#input2")
const input3 = document.querySelector("#input3")

stringResult1 = document.querySelector("#out1")
stringResult2 = document.querySelector("#out2")
stringResult3 = document.querySelector("#out3")

const but1 = document.querySelector("#batton")



but1.addEventListener('click', function() {
    let day = +input1.value
    let month = +input2.value
   	let sign = "a";
   	       if((month === 1) && (day <= 20) || (month == 12) && (day >= 22)) {
    sign = "Козерог";
   	} else if((month == 1) || (month == 2) && (day <= 19)) {
   		 sign = "Водолей"
   	} else if((month == 2) || (month == 3) && (day <= 20)) {
   		 sign = "Рыбы"
   	} else if((month == 3) || (month == 4) && (day <= 19)) {
   		 sign = "Овен"
   	} else if((month == 4) || (month == 5) && (day <= 21)) {
   		 sign = "Телец"
   	} else if((month == 5) || (month == 6) && (day <= 21)) {
   		 sign = "Близнецы"
   	} else if((month == 6) || (month == 7) && (day <= 23)) {
   		 sign = "Рак"
   	} else if((month == 7) || (month == 8) && (day <= 23)) {
   		 sign = "Лев"
   	} else if((month == 8) || (month == 9) && (day <= 23)) {
   		 sign = "Дева"
   	} else if((month == 9) || (month == 10) && (day <= 23)) {
   		 sign = "Весы"
   	} else if((month == 10) || (month == 11) && (day <= 22)) {
   	     sign = "Скорпион"
   	} else if((month == 12) || (month == 11) && (day > 22)) {
   		 sign = "Стрелец"
   	}


     let Y = +input3.value

     let result = ""
     let resultC = ""

     let animal = Y%12;
     let color = Y%10;
     let cvet 
     let pol


     switch (animal){
      case 0 : result += "обезьяна ";
      pol = 2
               break;
      case 1: result += "петух ";
      pol = 1
               break;  
      case 2: result += "собака ";
      pol = 2
               break;  
      case 3: result += "свинья ";
      pol = 2
               break;  
      case 4: result += "крыса ";
      pol = 2
               break;  
      case 5: result += "бык ";
      pol = 1
               break;  
      case 6: result += "тигр ";
      pol = 1
               break; 
      case 7: result += "кролик ";
      pol = 1
               break;  
      case 8: result += "дракон ";
      pol = 1
               break;  
      case 9: result += "змея ";
      pol = 2
               break;
      case 10: result += "лошадь ";
      pol = 2
               break; 
      case 11: result += "коза ";
      pol = 2
               break;  
   }

   if(pol==1) {
     switch (color){
        case 0: resultC = "Белый ";
        cvet = "#ffffff"
                 break;
        case 1: resultC = "Белый ";
        cvet = "ffffff"
                 break;  
        case 2: resultC = "Черный ";
        cvet = "#000000"
                 break;  
        case 3: resultC = "Черный ";
        cvet = "#000000"
                 break;  
        case 4: resultC = "Синий ";
        cvet = "#051afd"
                 break;  
        case 5: resultC = "Синий ";
        cvet = "#051afd"
                 break;  
        case 6: resultC = "Красный ";
        cvet = "#fd0505"
                 break; 
        case 7: resultC = "Красный ";
        cvet = "#fd0505"
                 break;  
        case 8: resultC = "Желтый ";
        cvet = "#f1fd05"
                 break;  
        case 9: resultC = "Желтый ";
        cvet = "#f1fd05"
                 break;           
     }
   }
   if(pol==2){
     switch (color){
      case 0: resultC = "Белая ";
      cvet = "#ffffff"
               break;
      case 1: resultC = "Белая ";
      cvet = "ffffff"
               break;  
      case 2: resultC = "Черная ";
      cvet = "#000000"
               break;  
      case 3: resultC = "Черная ";
      cvet = "#000000"
               break;  
      case 4: resultC = "Синяя ";
      cvet = "#051afd"
               break;  
      case 5: resultC = "Синяя ";
      cvet = "#051afd"
               break;  
      case 6: resultC = "Красная ";
      cvet = "#fd0505"
               break; 
      case 7: resultC = "Красная ";
      cvet = "#fd0505"
               break;  
      case 8: resultC = "Желтая ";
      cvet = "#f1fd05"
               break;  
      case 9: resultC = "Желтая ";
      cvet = "#f1fd05"
               break;           
      }
   }
        stringResult3.innerText = resultC
        stringResult3.style.color = cvet
        stringResult1.innerText = result

        stringResult2.innerText = sign


     })