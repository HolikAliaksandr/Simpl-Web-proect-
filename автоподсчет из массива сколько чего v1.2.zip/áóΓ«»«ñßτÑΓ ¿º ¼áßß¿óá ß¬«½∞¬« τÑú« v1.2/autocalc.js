const input = document.querySelector(".textareaElement")
const output = document.querySelector("#out")
const but = document.querySelector("#butt")

but.addEventListener('click', function(){
    mas = input.innerText
    const masiv = Array.from(mas)
    var structur1 = Array.from(new Set(Array.from(masiv))).map(z =>
        [z, (Array.from(masiv)).filter(i => i==z).length])

    let structur = [].concat(...structur1)
    let itog = new Array()
    
    for(let i=0; i<structur.length; i++){
        if ((i+1)%2==0){
        itog.push(structur[i] + ' ' + '. ')
        } else {
            itog.push('Symbol '+ '"'+ structur[i] +'"'+ ':')
        }
    }
    let string = new String()
    string = String (itog)
    let itog2 = string.replace(/,/g, " ");
    output.innerText = itog2
})
